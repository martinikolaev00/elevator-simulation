#include<iostream>
#include"building.hpp"
int main()

{
	building test;
		test.run();
	return 0;
}